"""
Structural precondition checks for hard mitigation actions.

These checks run before the LLM reviewer. They are deterministic guardrails for
cluster invariants the reviewer cannot reliably prove from prose alone.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class PreconditionResult:
    safe: bool
    reason: str = ""
    rule: str = "not-applicable"
    evidence: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


_TARGET_ARG_KEYS = (
    "name",
    "pod",
    "deployment",
    "service",
    "workload",
    "statefulset",
    "daemonset",
    "job",
    "node",
)
_SCALE_ARG_KEYS = ("replicas", "replica", "replica_count", "desired_replicas", "count")

_RESTART_RE = re.compile(r"(?i)(?<![a-z])(restart|rollout|recreate)(?![a-z])")
_SCALE_RE = re.compile(r"(?i)(?<![a-z])scale(?![a-z])")
_DRAIN_RE = re.compile(r"(?i)(?<![a-z])(drain|cordon|evict)(?![a-z])")
_PATCH_RE = re.compile(r"(?i)(?<![a-z])(patch|apply|update|set|edit)(?![a-z])")

_REPLICA_FIELD_RE = re.compile(
    r"(?i)\b(replicas|readyReplicas|availableReplicas|desiredReplicas|currentReplicas|updatedReplicas)\b\s*[:=]\s*\"?(\d+)"
)
_READY_FRACTION_RE = re.compile(r"(?i)\bready\b[^\n\d]*(\d+)\s*/\s*(\d+)")
_PDB_ZERO_RE = re.compile(r"(?i)\b(?:disruptionsAllowed|allowed\s+disruptions)\b\s*[:=]?\s*\"?0\b")
_PDB_DISRUPTIONS_RE = re.compile(
    r"(?i)\b(?:disruptionsAllowed|allowed\s+disruptions)\b\s*[:=]?\s*\"?(\d+)\b"
)
_PDB_MARKER_RE = re.compile(r"(?i)\b(?:poddisruptionbudget|pdb|disruptionsAllowed)\b")
_NODE_COUNT_RE = re.compile(r"(?i)\b(?:schedulableNodes|nodeCount|nodes)\b\s*[:=]\s*\"?(\d+)\b")
_HIGH_TRAFFIC_RE = re.compile(
    r"(?i)\b(?:high\s+traffic|nonzero\s+traffic|requests?_per_second|rps|qps|traffic)\b"
)
_EXPLICIT_HIGH_TRAFFIC_RE = re.compile(r"(?i)\b(?:high\s+traffic|nonzero\s+traffic|active\s+traffic)\b")
_TRAFFIC_VALUE_RE = re.compile(
    r"(?i)\b(?:requests?_per_second|rps|qps|traffic)\b[^\n\d]{0,24}(\d+(?:\.\d+)?)"
)


def check_preconditions(
    tool_def: Dict[str, Any],
    tool_args: Dict[str, Any],
    scan_trace: Iterable[Dict[str, Any]],
) -> PreconditionResult:
    """Return a fail-closed verdict for structural hard-action preconditions."""
    action_class = str(tool_def.get("_action_class", ""))
    if action_class != "hard":
        return PreconditionResult(safe=True)

    haystack = _tool_haystack(tool_def)

    if _SCALE_RE.search(haystack):
        entries = _trace_texts_for_target(scan_trace, _target_name(tool_args))
        return _check_scale(tool_args, entries)
    if _RESTART_RE.search(haystack):
        entries = _trace_texts_for_target(scan_trace, _target_name(tool_args))
        return _check_restart(tool_args, entries)
    if _DRAIN_RE.search(haystack):
        entries = _trace_texts_for_target(scan_trace, None)
        return _check_drain(entries)
    if _PATCH_RE.search(haystack):
        entries = _trace_texts_for_target(scan_trace, _target_name(tool_args))
        return _check_patch(entries)

    return PreconditionResult(safe=True, rule="no-structural-rule")


def _check_restart(tool_args: Dict[str, Any], entries: List[str]) -> PreconditionResult:
    ready_replicas = _ready_replica_counts(entries)
    if not entries or not ready_replicas:
        return PreconditionResult(
            safe=False,
            rule="restart-requires-replica-evidence",
            reason=(
                "restart/rollout requires prior ready/available replica evidence; "
                "call a soft read tool for the target and verify more than one "
                "ready/available replica"
            ),
        )

    max_ready = max(ready_replicas) if ready_replicas else 0
    if max_ready <= 1:
        target = _target_name(tool_args) or "target"
        return PreconditionResult(
            safe=False,
            rule="restart-single-replica-block",
            reason=f"restarting {target!r} would leave zero redundant replicas available",
            evidence=[f"ready_replica_evidence: {ready_replicas}"],
        )

    return PreconditionResult(
        safe=True,
        rule="restart-replica-evidence-ok",
        evidence=[f"ready_replica_evidence: {ready_replicas}"],
    )


def _check_scale(tool_args: Dict[str, Any], entries: List[str]) -> PreconditionResult:
    desired = _desired_replica_count(tool_args)
    if desired is None:
        return PreconditionResult(
            safe=False,
            rule="scale-missing-replica-target",
            reason="scale action is missing an explicit desired replica count",
        )
    if desired < 1:
        return PreconditionResult(
            safe=False,
            rule="scale-below-one-block",
            reason="cannot scale a workload below one replica",
            evidence=[f"desired_replicas={desired}"],
        )

    current_counts = _replica_counts(entries)
    if not entries or not current_counts:
        return PreconditionResult(
            safe=False,
            rule="scale-requires-replica-evidence",
            reason=(
                "scale action requires prior replica evidence for the target; "
                "call a soft read tool before proposing a desired replica count"
            ),
            evidence=[f"desired_replicas={desired}"],
        )

    current_max = max(current_counts)
    max_safe_desired = max(current_max * 2, current_max + 3)
    if desired > max_safe_desired:
        return PreconditionResult(
            safe=False,
            rule="scale-up-too-large-block",
            reason=(
                f"scale-up from observed replica evidence {current_counts} to {desired} "
                f"exceeds the per-action safety cap of {max_safe_desired} replicas"
            ),
            evidence=[f"desired_replicas={desired}", f"current_replica_evidence={current_counts}"],
        )

    if current_counts and desired < max(current_counts) and _has_high_traffic(entries):
        return PreconditionResult(
            safe=False,
            rule="scale-down-high-traffic-block",
            reason="scale-down is blocked while prior evidence indicates active traffic",
            evidence=[f"desired_replicas={desired}", f"current_replica_evidence={current_counts}"],
        )

    return PreconditionResult(
        safe=True,
        rule="scale-floor-ok",
        evidence=[f"desired_replicas={desired}"],
    )


def _check_drain(entries: List[str]) -> PreconditionResult:
    joined = "\n".join(entries)
    if not _PDB_MARKER_RE.search(joined):
        return PreconditionResult(
            safe=False,
            rule="drain-requires-pdb-evidence",
            reason="drain/evict requires prior PodDisruptionBudget evidence",
        )
    if _PDB_ZERO_RE.search(joined):
        return PreconditionResult(
            safe=False,
            rule="drain-pdb-zero-block",
            reason="drain/evict is blocked because a PodDisruptionBudget allows zero disruptions",
            evidence=[_snippet(joined)],
        )

    disruption_counts = _pdb_disruptions_allowed(entries)
    if not disruption_counts or max(disruption_counts) <= 0:
        return PreconditionResult(
            safe=False,
            rule="drain-requires-positive-pdb-evidence",
            reason="drain/evict requires explicit evidence that a PodDisruptionBudget allows at least one disruption",
            evidence=[_snippet(joined)],
        )

    node_counts = [int(m.group(1)) for text in entries for m in _NODE_COUNT_RE.finditer(text)]
    if not node_counts:
        return PreconditionResult(
            safe=False,
            rule="drain-requires-node-count-evidence",
            reason="drain/evict requires prior evidence that more than one schedulable node exists",
            evidence=[_snippet(joined)],
        )
    if node_counts and max(node_counts) <= 1:
        return PreconditionResult(
            safe=False,
            rule="drain-single-node-block",
            reason="drain/evict is blocked because evidence shows only one schedulable node",
            evidence=[f"node_count_evidence={node_counts}"],
        )

    return PreconditionResult(
        safe=True,
        rule="drain-pdb-evidence-ok",
        evidence=[
            f"disruptions_allowed_evidence={disruption_counts}",
            f"node_count_evidence={node_counts}",
            _snippet(joined),
        ],
    )


def _check_patch(entries: List[str]) -> PreconditionResult:
    joined = "\n".join(entries)
    warnings: List[str] = []
    if not entries:
        return PreconditionResult(
            safe=False,
            rule="patch-requires-target-evidence",
            reason="patch/apply/update requires prior target evidence from a soft read tool",
        )
    if re.search(r"(?i)\b(ownerReferences|controlled\s+by|controller)\b", joined):
        warnings.append("target has controller ownership evidence; controller may revert manual patch")
    return PreconditionResult(safe=True, rule="patch-allowed-with-warnings", warnings=warnings)


def _tool_haystack(tool_def: Dict[str, Any]) -> str:
    return f"{tool_def.get('name', '')}\n{tool_def.get('description', '')}"


def _target_name(args: Dict[str, Any]) -> Optional[str]:
    for key in _TARGET_ARG_KEYS:
        value = args.get(key)
        if value:
            return str(value).strip()
    return None


def _desired_replica_count(args: Dict[str, Any]) -> Optional[int]:
    for key in _SCALE_ARG_KEYS:
        value = args.get(key)
        if value is None or value == "":
            continue
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
    return None


def _trace_texts_for_target(
    scan_trace: Iterable[Dict[str, Any]],
    target: Optional[str],
) -> List[str]:
    target_l = target.lower() if target else ""
    texts: List[str] = []
    for entry in scan_trace:
        text = _entry_text(entry)
        if not text:
            continue
        if target_l and target_l not in text.lower():
            continue
        texts.append(text)
    if target_l:
        return texts
    return [_entry_text(entry) for entry in scan_trace if _entry_text(entry)]


def _entry_text(entry: Dict[str, Any]) -> str:
    if "result_text" in entry:
        return str(entry.get("result_text") or "")
    if "result" in entry:
        return _json_text(entry.get("result"))
    return _json_text(entry)


def _json_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str, sort_keys=True)
    except TypeError:
        return str(value)


def _replica_counts(entries: List[str]) -> List[int]:
    counts: List[int] = []
    for text in entries:
        counts.extend(int(m.group(2)) for m in _REPLICA_FIELD_RE.finditer(text))
        for match in _READY_FRACTION_RE.finditer(text):
            ready, desired = int(match.group(1)), int(match.group(2))
            counts.extend([ready, desired])
    return counts


def _ready_replica_counts(entries: List[str]) -> List[int]:
    counts: List[int] = []
    for text in entries:
        for match in _REPLICA_FIELD_RE.finditer(text):
            field = match.group(1).lower()
            if field in {"readyreplicas", "availablereplicas"}:
                counts.append(int(match.group(2)))
        for match in _READY_FRACTION_RE.finditer(text):
            counts.append(int(match.group(1)))
    return counts


def _pdb_disruptions_allowed(entries: List[str]) -> List[int]:
    return [int(m.group(1)) for text in entries for m in _PDB_DISRUPTIONS_RE.finditer(text)]


def _has_high_traffic(entries: List[str]) -> bool:
    for text in entries:
        if _EXPLICIT_HIGH_TRAFFIC_RE.search(text):
            return True
        if not _HIGH_TRAFFIC_RE.search(text):
            continue
        for match in _TRAFFIC_VALUE_RE.finditer(text):
            try:
                if float(match.group(1)) > 0:
                    return True
            except ValueError:
                continue
    return False


def _snippet(text: str, limit: int = 240) -> str:
    clean = " ".join((text or "").split())
    return clean[:limit]