"""Fail-closed guard for suppressing hard actions during active chaos."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

from mcp.client import MCPScope


@dataclass
class ChaosGuardResult:
    allowed: bool
    reason: str = ""
    rule: str = "not-applicable"
    evidence: List[str] = field(default_factory=list)


_CHAOS_MARKER_RE = re.compile(r"(?i)\b(?:chaosengine|chaosresult|litmuschaos|chaos\s+engine|chaos\s+result)\b")
_ACTIVE_RE = re.compile(
    r"(?i)\b(?:phase|status|engineStatus|experimentStatus|verdict)\b\s*[:=]\s*\"?(?:running|active|awaited|in[-_ ]?progress)\b"
)
_ACTIVE_TEXT_RE = re.compile(r"(?i)\b(?:phase:\s*Running|verdict:\s*Awaited|engineStatus:\s*active|experimentStatus:\s*Running)\b")


def evaluate_chaos_guard(
    tool_def: Dict[str, Any],
    scan_trace: Iterable[Dict[str, Any]],
    scope: Optional[MCPScope],
    enabled: bool = True,
) -> ChaosGuardResult:
    """Block hard actions when trace evidence shows active chaos in scope."""
    if not enabled:
        return ChaosGuardResult(allowed=True, rule="disabled")
    if str(tool_def.get("_action_class", "")) != "hard":
        return ChaosGuardResult(allowed=True)

    scope_names = set(getattr(scope, "namespaces", []) or [])
    for entry in scan_trace:
        text = _entry_text(entry)
        if not text:
            continue
        if not _looks_active_chaos(text):
            continue
        if scope_names and not _mentions_scope(text, scope_names):
            continue
        return ChaosGuardResult(
            allowed=False,
            rule="active-chaos-block",
            reason="chaos experiment appears active in scope; re-evaluate after completion",
            evidence=[_snippet(text)],
        )

    return ChaosGuardResult(allowed=True, rule="no-active-chaos-detected")


def _looks_active_chaos(text: str) -> bool:
    if not _CHAOS_MARKER_RE.search(text):
        return False
    return bool(_ACTIVE_RE.search(text) or _ACTIVE_TEXT_RE.search(text))


def _mentions_scope(text: str, namespaces: set[str]) -> bool:
    lowered = text.lower()
    return any(ns.lower() in lowered for ns in namespaces)


def _entry_text(entry: Dict[str, Any]) -> str:
    if "result_text" in entry:
        return str(entry.get("result_text") or "")
    if "result" in entry:
        return _json_text(entry.get("result"))
    return _json_text(entry)


def _json_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str, sort_keys=True)
    except TypeError:
        return str(value)


def _snippet(text: str, limit: int = 240) -> str:
    return " ".join((text or "").split())[:limit]