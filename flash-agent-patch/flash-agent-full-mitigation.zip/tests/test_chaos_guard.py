"""Tests for active-chaos hard-action suppression."""

from __future__ import annotations

from mcp.client import MCPScope
from policy.chaos_guard import evaluate_chaos_guard


def _tool(action_class: str = "hard") -> dict:
    return {"name": "restart_pod", "_action_class": action_class}


def test_blocks_hard_action_when_chaos_engine_running_in_scope() -> None:
    trace = [
        {
            "tool": "list_events",
            "result_text": "kind: ChaosEngine namespace: alpha spec: pod-delete status: phase: Running",
        }
    ]
    result = evaluate_chaos_guard(
        _tool(), trace, MCPScope(kind="namespace", namespaces=["alpha"])
    )
    assert not result.allowed
    assert result.rule == "active-chaos-block"


def test_ignores_chaos_marker_from_other_namespace() -> None:
    trace = [
        {
            "tool": "list_events",
            "result_text": "kind: ChaosEngine namespace: beta status: phase: Running",
        }
    ]
    result = evaluate_chaos_guard(
        _tool(), trace, MCPScope(kind="namespace", namespaces=["alpha"])
    )
    assert result.allowed


def test_soft_actions_are_allowed_during_active_chaos() -> None:
    trace = [
        {
            "tool": "list_events",
            "result_text": "kind: ChaosResult namespace: alpha verdict: Awaited",
        }
    ]
    result = evaluate_chaos_guard(
        _tool("soft"), trace, MCPScope(kind="namespace", namespaces=["alpha"])
    )
    assert result.allowed


def test_disabled_guard_allows_hard_action() -> None:
    trace = [
        {
            "tool": "list_events",
            "result_text": "kind: ChaosEngine namespace: alpha status: phase: Running",
        }
    ]
    result = evaluate_chaos_guard(
        _tool(), trace, MCPScope(kind="namespace", namespaces=["alpha"]), enabled=False
    )
    assert result.allowed
    assert result.rule == "disabled"