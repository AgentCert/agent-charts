"""Tests for structural hard-action preconditions."""

from __future__ import annotations

from policy.precondition import check_preconditions


def _tool(name: str, description: str = "") -> dict:
    return {
        "name": name,
        "description": description or name,
        "inputSchema": {},
        "_action_class": "hard",
    }


def _trace(text: str) -> list[dict]:
    return [{"tool": "get", "args": {"name": "api"}, "result_text": text}]


def test_restart_blocks_when_replica_evidence_missing() -> None:
    result = check_preconditions(
        _tool("restart_pod", "Restart a pod"),
        {"namespace": "alpha", "name": "api"},
        [],
    )
    assert not result.safe
    assert result.rule == "restart-requires-replica-evidence"


def test_restart_blocks_single_replica() -> None:
    result = check_preconditions(
        _tool("restart_pod", "Restart a pod"),
        {"namespace": "alpha", "name": "api"},
        _trace("pod api replicas=1 readyReplicas=1 restart_count=12"),
    )
    assert not result.safe
    assert result.rule == "restart-single-replica-block"


def test_restart_blocks_when_only_desired_replica_is_redundant() -> None:
    result = check_preconditions(
        _tool("restart_pod", "Restart a pod"),
        {"namespace": "alpha", "name": "api"},
        _trace("deployment api replicas=3 readyReplicas=1 restart_count=12"),
    )
    assert not result.safe
    assert result.rule == "restart-single-replica-block"


def test_restart_allows_redundant_replicas() -> None:
    result = check_preconditions(
        _tool("restart_pod", "Restart a pod"),
        {"namespace": "alpha", "name": "api"},
        _trace("deployment api replicas=3 readyReplicas=3 restart_count=12"),
    )
    assert result.safe
    assert result.rule == "restart-replica-evidence-ok"


def test_scale_blocks_below_one() -> None:
    result = check_preconditions(
        _tool("scale_dep", "Scale a deployment"),
        {"namespace": "alpha", "name": "api", "replicas": 0},
        _trace("deployment api replicas=3 readyReplicas=3"),
    )
    assert not result.safe
    assert result.rule == "scale-below-one-block"


def test_scale_requires_replica_evidence() -> None:
    result = check_preconditions(
        _tool("scale_dep", "Scale a deployment"),
        {"namespace": "alpha", "name": "api", "replicas": 3},
        [],
    )
    assert not result.safe
    assert result.rule == "scale-requires-replica-evidence"


def test_scale_requires_target_matched_evidence() -> None:
    result = check_preconditions(
        _tool("scale_dep", "Scale a deployment"),
        {"namespace": "alpha", "name": "api", "replicas": 3},
        _trace("deployment web replicas=2 readyReplicas=2"),
    )
    assert not result.safe
    assert result.rule == "scale-requires-replica-evidence"


def test_scale_blocks_large_jump() -> None:
    result = check_preconditions(
        _tool("scale_dep", "Scale a deployment"),
        {"namespace": "alpha", "name": "api", "replicas": 20},
        _trace("deployment api replicas=3 readyReplicas=3 traffic rps=0"),
    )
    assert not result.safe
    assert result.rule == "scale-up-too-large-block"


def test_scale_down_blocks_with_high_traffic() -> None:
    result = check_preconditions(
        _tool("scale_dep", "Scale a deployment"),
        {"namespace": "alpha", "name": "api", "replicas": 1},
        _trace("deployment api replicas=4 readyReplicas=4 traffic rps=180"),
    )
    assert not result.safe
    assert result.rule == "scale-down-high-traffic-block"


def test_scale_down_allows_zero_traffic() -> None:
    result = check_preconditions(
        _tool("scale_dep", "Scale a deployment"),
        {"namespace": "alpha", "name": "api", "replicas": 1},
        _trace("deployment api replicas=4 readyReplicas=4 traffic rps=0"),
    )
    assert result.safe


def test_drain_requires_pdb_evidence() -> None:
    result = check_preconditions(
        _tool("drain_node", "Drain a node"),
        {"node": "worker-1"},
        _trace("node worker-1 schedulableNodes=3"),
    )
    assert not result.safe
    assert result.rule == "drain-requires-pdb-evidence"


def test_drain_blocks_zero_disruptions() -> None:
    result = check_preconditions(
        _tool("drain_node", "Drain a node"),
        {"node": "worker-1"},
        _trace("PodDisruptionBudget api-pdb disruptionsAllowed: 0 schedulableNodes=3"),
    )
    assert not result.safe
    assert result.rule == "drain-pdb-zero-block"


def test_drain_requires_positive_pdb_evidence() -> None:
    result = check_preconditions(
        _tool("drain_node", "Drain a node"),
        {"node": "worker-1"},
        _trace("PodDisruptionBudget api-pdb exists schedulableNodes=3"),
    )
    assert not result.safe
    assert result.rule == "drain-requires-positive-pdb-evidence"


def test_drain_requires_node_count_evidence() -> None:
    result = check_preconditions(
        _tool("drain_node", "Drain a node"),
        {"node": "worker-1"},
        _trace("PodDisruptionBudget api-pdb disruptionsAllowed: 1"),
    )
    assert not result.safe
    assert result.rule == "drain-requires-node-count-evidence"


def test_drain_allows_positive_pdb_and_redundant_nodes() -> None:
    result = check_preconditions(
        _tool("drain_node", "Drain a node"),
        {"node": "worker-1"},
        _trace("PodDisruptionBudget api-pdb disruptionsAllowed: 1 schedulableNodes=3"),
    )
    assert result.safe


def test_patch_warns_on_controller_owned_target() -> None:
    result = check_preconditions(
        _tool("patch_dep", "Patch a deployment"),
        {"namespace": "alpha", "name": "api"},
        _trace("pod api ownerReferences kind=ReplicaSet controller=true"),
    )
    assert result.safe
    assert result.warnings


def test_patch_requires_target_evidence() -> None:
    result = check_preconditions(
        _tool("patch_dep", "Patch a deployment"),
        {"namespace": "alpha", "name": "api"},
        [],
    )
    assert not result.safe
    assert result.rule == "patch-requires-target-evidence"