# Flash-Agent — ACE Setup & Mitigation Onboarding

Complete guide: fresh machine → ACE stack running → flash-agent deployed in **mitigate mode** → end-to-end chaos experiment verified.

---

## What flash-agent does

flash-agent is an autonomous SRE agent that watches a Kubernetes namespace during chaos experiments. It uses MCP (Model Context Protocol) tools to:

- **Observe mode** (`AGENT_MODE=observe`): discover resource health, classify issues, write recommendations — read-only, zero cluster mutations.
- **Mitigate mode** (`AGENT_MODE=mitigate`): everything above, plus a closed-loop remediation pipeline that can restart pods, scale replicas, patch deployments, and adjust HPAs — subject to a multi-layer safety gate.

The mitigation gate (in order):
```
1. Classifier     — violent tools (exec/delete/purge) filtered out before LLM sees them
2. Scope gate     — blocks any action outside AGENT_SCOPE_NAMESPACE
3. Chaos guard    — blocks hard actions when active chaos is detected in the trace
4. Preconditions  — blocks if: PDB at zero, single replica, no evidence of benefit
5. 2-pass review  — LLM justify + adversarial challenge; both must pass
                  → APPROVED → execute
                  → episode recorded → reconciled next scan
```

---

## Architecture

```
Host (Docker Compose)                       kind cluster: agentcert
─────────────────────────────────────       ────────────────────────────────────────
agentcert-mongo      :27017                 litmus namespace:
agentcert-auth       :3000 / :3030            chaos-operator
agentcert-graphql    :8081                    chaos-exporter
agentcert-web        :2001                    event-tracker
litellm-proxy        :14000                   workflow-controller
certifier_app        :8000                    kubernetes-mcp-server   :8081
langfuse-web         :4000                    prometheus-mcp-server   :9090
                                              subscriber
                                              flash-agent  ← Helm deploy
```

Compose services reach the cluster via the kind docker-bridge gateway (`172.26.0.1` by default — verify yours, see Step 2).  
In-cluster pods reach host services (LiteLLM, graphql) via the same gateway IP.

---

## Prerequisites

| Tool | Min version | Install hint |
|------|------------|--------------|
| Docker Engine | 26+ | https://docs.docker.com/engine/install/ |
| Docker Compose | 2.21+ | bundled with Docker Desktop |
| kubectl | any | `curl -LO https://dl.k8s.io/release/stable.txt` |
| kind | 0.22+ | `go install sigs.k8s.io/kind@latest` |
| helm | 3.12+ | see install below |
| git | any | distro package |

**Install helm without root:**
```bash
curl -fsSL https://get.helm.sh/helm-v3.21.2-linux-amd64.tar.gz | tar -xz -C /tmp
mkdir -p ~/.local/bin && cp /tmp/linux-amd64/helm ~/.local/bin/helm
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc
helm version
```

---

## Part 1: ACE Stack Setup

### Step 1 — Clone ace-monorepo

```bash
git clone https://github.com/AgentCert/ace-monorepo.git ~/ace-monorepo
cd ~/ace-monorepo
git submodule update --init --recursive
```

Verify:
```bash
ls flash-agent/   # build-flash-agent.sh, ONBOARDING.md, ...
ls agent-charts/  # charts/flash-agent/...
```

---

### Step 2 — Detect the kind gateway IP

The kind docker-network gateway is **not always 172.26.0.1** — it depends on how many docker networks exist on your machine. Detect it:

```bash
docker network inspect kind -f '{{range .IPAM.Config}}{{.Gateway}} {{end}}' 2>/dev/null \
  || echo "kind network not up yet — run after docker compose up"
```

Use this IP wherever `172.26.0.1` appears below.

---

### Step 3 — Configure `.env`

```bash
cp .env.example .env
```

Edit `.env` and fill in these sections (everything else has working defaults):

```bash
# ── LLM provider (Azure OpenAI or compatible) ────────────────────────────────
AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
AZURE_OPENAI_CHAT_DEPLOYMENT_NAME=gpt-4o   # your chat deployment name

# ── kind gateway — replace 172.26.0.1 with your actual gateway IP ────────────
PORTAL_ENDPOINT=http://172.26.0.1:8081
LITMUS_SVC_ENDPOINT=http://172.26.0.1:3000
SUBSCRIBER_CALLBACK_URL=http://172.26.0.1:8081
LITELLM_HOST=http://172.26.0.1:14000

# ── Flash-agent (these have correct defaults; change only if needed) ──────────
FLASH_AGENT_IMAGE=agentcert/agentcert-flash-agent:latest
K8S_MCP_URL=http://kubernetes-mcp-server.litmus.svc.cluster.local:8081/mcp
PROM_MCP_URL=http://prometheus-mcp-server.litmus.svc.cluster.local:9090/mcp
CHAOS_NAMESPACE=litmus
AGENT_CHARTS_ROOT=/srv/projects/ace-monorepo/agent-charts

# ── Mitigation (change AGENT_MODE when you are ready to test mitigation) ─────
AGENT_MODE=observe              # start with observe, switch to mitigate for E2E test
AGENT_SCOPE_NAMESPACE=litmus
REVIEWER_MODEL_ALIAS=           # leave empty to use MODEL_ALIAS (degraded but works)
MITIGATION_ALLOW_DISCOVERED_SCOPE=false
MITIGATION_REVIEW_ITERS=2
MITIGATION_AUDIT_PATH=/tmp/audit.jsonl
AGENT_MEMORY_PATH=/tmp/memory.jsonl
MEMORY_TTL_DAYS=7
MITIGATION_HARD_ACTION_SCAN_LIMIT=2
MITIGATION_CHAOS_GUARD_ENABLED=true
```

> **Tip**: set `REVIEWER_MODEL_ALIAS` to a second model (e.g. `gpt-4o-mini`) for true independent review. With an empty value the same model reviews its own proposal — it still runs 2 passes but correlated reasoning is a risk.

---

### Step 4 — Start the Docker Compose stack

```bash
cd ~/ace-monorepo
docker compose up -d
```

The `cluster-init` one-shot container creates (or reuses) the `agentcert` kind cluster, then exits. The remaining services start on the host network.

Wait ~90 seconds, then verify:
```bash
docker ps --format "table {{.Names}}\t{{.Status}}"
```

Expected running containers:

| Container | Port | Purpose |
|-----------|------|---------|
| `agentcert-mongo` | 27017 | MongoDB |
| `agentcert-auth` | 3000/3030 | Auth service |
| `agentcert-graphql` | 8081 | GraphQL control plane |
| `agentcert-web` | 2001 | AgentCert UI |
| `litellm-proxy` | 14000 | LiteLLM gateway |
| `certifier_app` | 8000 | Certifier API |
| `ace-langfuse-web-1` | 4000 | Langfuse traces |

---

### Step 5 — Verify the Kubernetes cluster

```bash
kubectl cluster-info
kubectl get nodes
kubectl get namespaces
```

Expected namespaces: `litmus`, `kube-system`, `local-path-storage`, `default`.

Verify Litmus chaos infrastructure (deployed automatically by graphql server on init):
```bash
kubectl get pods -n litmus
```

All of these must be `Running` before proceeding:
```
chaos-exporter-*
chaos-operator-*
event-tracker-*
workflow-controller-*
kubernetes-mcp-server-*   ← K8s MCP tools
prometheus-mcp-server-*   ← Prometheus MCP tools
subscriber-*
```

> If `kubernetes-mcp-server` or `prometheus-mcp-server` are missing, check graphql logs:
> ```bash
> docker logs agentcert-graphql 2>&1 | grep -i "mcp\|infra"
> ```
> The MCP servers are deployed by the graphql server when the subscriber first connects and registers the infrastructure.

---

## Part 2: Build flash-agent Image

### Step 6 — Build and load the flash-agent image

The build script compiles a tagged image, loads it into the kind cluster, and syncs the image reference in `.env`:

```bash
cd ~/ace-monorepo
bash flash-agent/build-flash-agent.sh
```

The script:
1. Prunes old flash-agent images from the host
2. Builds `agentcert/agentcert-flash-agent:<timestamp>`
3. Tags `:latest` and `:dev`
4. Loads all tags into the kind cluster (`kind load docker-image`)
5. Updates `FLASH_AGENT_IMAGE` in `.env`
6. If a `litmusportal-server` K8s deployment exists, patches it with the new image + all env vars (including mitigation vars)

To push to Docker Hub (needed for cloud clusters that cannot do `kind load`):
```bash
bash scripts/build-and-push.sh
```

---

## Part 3: Deploy Flash-Agent via Helm

### Step 7 — Deploy in observe mode first (smoke test)

```bash
cd ~/ace-monorepo

LITELLM_KEY=$(grep "^LITELLM_MASTER_KEY=" .env | cut -d'=' -f2-)

helm upgrade --install flash-agent agent-charts/charts/flash-agent/ \
  --namespace litmus \
  --create-namespace \
  --set agent.config.AGENT_MODE=observe \
  --set agent.config.AGENT_SCOPE_NAMESPACE=litmus \
  --set agent.config.MCP_URLS="http://kubernetes-mcp-server.litmus.svc.cluster.local:8081/mcp,http://prometheus-mcp-server.litmus.svc.cluster.local:9090/mcp" \
  --set agent.config.OPENAI_BASE_URL="http://172.26.0.1:14000/v1" \
  --set agent.secret.OPENAI_API_KEY="${LITELLM_KEY}" \
  --set sidecar.enabled=false \
  --timeout 5m
```

Wait for the pod:
```bash
kubectl rollout status deployment/flash-agent -n litmus --timeout=120s
kubectl get pods -n litmus -l app=flash-agent
```

Check startup logs — look for tool discovery:
```bash
kubectl logs deployment/flash-agent -n litmus -c agent | head -40
```

Expected output:
```
[INFO] AGENT_MODE=observe
[INFO] Connecting to MCP servers...
[INFO] Found 19 tools from http://kubernetes-mcp-server.litmus.svc.cluster.local:8081/mcp
[INFO] Found 6 tools from http://prometheus-mcp-server.litmus.svc.cluster.local:9090/mcp
[INFO] Filtered 4 violent tool(s)
[INFO] Discovered 21 tools total
[INFO] Scope: namespace='litmus' (source=explicit)
```

If the agent starts but shows 0 tools, the MCP servers aren't ready yet. Check:
```bash
kubectl get pods -n litmus -l app=kubernetes-mcp-server
kubectl get pods -n litmus -l app=prometheus-mcp-server
```

---

### Step 8 — Upgrade to mitigate mode

```bash
helm upgrade flash-agent agent-charts/charts/flash-agent/ \
  --namespace litmus \
  --reuse-values \
  --set agent.config.AGENT_MODE=mitigate \
  --set agent.config.REVIEWER_MODEL_ALIAS="" \
  --set agent.config.MITIGATION_ALLOW_DISCOVERED_SCOPE=false \
  --set agent.config.MITIGATION_REVIEW_ITERS=2 \
  --set agent.config.MITIGATION_AUDIT_PATH=/tmp/audit.jsonl \
  --set agent.config.AGENT_MEMORY_PATH=/tmp/memory.jsonl \
  --timeout 5m
```

Verify the env vars are set in the running pod:
```bash
kubectl exec deployment/flash-agent -n litmus -c agent -- env | \
  grep -E "AGENT_MODE|REVIEWER_MODEL|MCP_URLS|OPENAI_BASE|AGENT_SCOPE|MITIGATION"
```

Expected:
```
AGENT_MODE=mitigate
AGENT_SCOPE_NAMESPACE=litmus
MITIGATION_ALLOW_DISCOVERED_SCOPE=false
MITIGATION_REVIEW_ITERS=2
MITIGATION_AUDIT_PATH=/tmp/audit.jsonl
```

---

## Part 4: End-to-End Chaos Experiment

### Step 9 — Apply a pod-delete chaos experiment

This experiment targets pods in the `litmus` namespace. Flash-agent will detect the deleted pods and attempt to remediate (restart affected deployments or scale replicas).

```bash
cat <<'EOF' | kubectl apply -f -
apiVersion: litmuschaos.io/v1alpha1
kind: ChaosEngine
metadata:
  name: flash-mitigate-test
  namespace: litmus
spec:
  appinfo:
    appns: litmus
    applabel: "app=chaos-exporter"
    appkind: deployment
  chaosServiceAccount: litmus-admin
  experiments:
    - name: pod-delete
      spec:
        components:
          env:
            - name: TOTAL_CHAOS_DURATION
              value: "30"
            - name: CHAOS_INTERVAL
              value: "10"
            - name: FORCE
              value: "false"
EOF
```

---

### Step 10 — Watch flash-agent respond

Stream logs in a separate terminal:
```bash
kubectl logs -f deployment/flash-agent -n litmus -c agent
```

Key log lines to watch for:
```
[INFO] AGENT_MODE=mitigate — remediation enabled
[INFO] Scan started
[INFO] Detected: pod deletion / crash-loop in namespace litmus
[WARNING] namespace-litmus — Active LitmusChaos experiment detected → chaos_guard ACTIVE
[INFO] Gate ALLOW: hard action approved after 2-pass review
[INFO] Executed: apps/deployments patch chaos-exporter (scale replicas: 1→2)
[INFO] Audit entry written to /tmp/audit.jsonl
```

If chaos-guard blocks the action (chaos is still active), that is **correct** — the guard prevents hard actions while chaos is intentionally running. Actions are approved after chaos completes.

---

### Step 11 — Verify chaos engine completed

```bash
kubectl get chaosengine flash-mitigate-test -n litmus \
  -o jsonpath='{.status.engineStatus}' && echo
# Expected: completed

kubectl get chaosresult flash-mitigate-test-pod-delete -n litmus \
  -o jsonpath='{.status.verdict}' && echo
# Expected: Pass
```

---

### Step 12 — Read the audit log

Every gate decision (allow/block) and every tool execution is logged:
```bash
kubectl exec deployment/flash-agent -n litmus -c agent -- cat /tmp/audit.jsonl
```

Each line is a JSON object:
```json
{"timestamp": "2026-06-23T...", "action": "apps/deployments patch", "target": "chaos-exporter",
 "verdict": "ALLOW", "review_iters": 2, "gate_stages": ["scope:pass","chaos_guard:pass","precondition:pass","review:pass"]}
```

---

## Configuration Reference

All configuration is via environment variables. The agent reads them at startup via `config.py:AgentConfig.from_env()`.

| Variable | Default | Description |
|----------|---------|-------------|
| `AGENT_MODE` | `observe` | `observe` = read-only, `mitigate` = closed-loop |
| `MCP_URLS` | — | Comma-separated MCP server URLs |
| `OPENAI_BASE_URL` | — | LiteLLM proxy base URL (with `/v1`) |
| `OPENAI_API_KEY` | — | LiteLLM master key |
| `MODEL_ALIAS` | — | LiteLLM model alias (e.g. `gpt-4o`) |
| `AGENT_SCOPE_NAMESPACE` | — | Namespace the agent is bound to |
| `REVIEWER_MODEL_ALIAS` | `""` | Second model for review; empty = use main model |
| `MITIGATION_ALLOW_DISCOVERED_SCOPE` | `false` | Allow acting on auto-discovered scope |
| `MITIGATION_REVIEW_ITERS` | `2` | Review passes before approving hard actions |
| `MITIGATION_AUDIT_PATH` | `""` | JSONL audit log path inside pod |
| `AGENT_MEMORY_PATH` | `""` | Episode memory store path inside pod |
| `MEMORY_TTL_DAYS` | `7` | Days before pruning old episodes |
| `MITIGATION_HARD_ACTION_SCAN_LIMIT` | `2` | Max hard actions per target per scan |
| `MITIGATION_CHAOS_GUARD_ENABLED` | `true` | Block hard actions during active chaos |

---

## Common Operations

**Switch modes without redeploying:**
```bash
# Switch to mitigate
helm upgrade flash-agent agent-charts/charts/flash-agent/ \
  --namespace litmus --reuse-values \
  --set agent.config.AGENT_MODE=mitigate --timeout 5m

# Switch back to observe
helm upgrade flash-agent agent-charts/charts/flash-agent/ \
  --namespace litmus --reuse-values \
  --set agent.config.AGENT_MODE=observe --timeout 5m
```

**Rebuild after code change:**
```bash
bash flash-agent/build-flash-agent.sh
kubectl rollout restart deployment/flash-agent -n litmus
kubectl rollout status deployment/flash-agent -n litmus
```

**Uninstall:**
```bash
helm uninstall flash-agent -n litmus
```

**Rollback:**
```bash
helm rollback flash-agent -n litmus
```

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Pod `CrashLoopBackOff` | `OPENAI_BASE_URL` wrong or LiteLLM not up | Check `docker ps | grep litellm` and verify gateway IP |
| `0 tools discovered` | MCP servers not ready | `kubectl get pods -n litmus -l app=kubernetes-mcp-server` |
| `AGENT_MODE=observe` even after setting mitigate | Helm `--reuse-values` picked up old ConfigMap | `helm upgrade ... --set agent.config.AGENT_MODE=mitigate` explicitly |
| All hard actions blocked by `chaos_guard` | Chaos experiment still running | Wait for chaos to complete, or set `MITIGATION_CHAOS_GUARD_ENABLED=false` for testing |
| Gate blocks with `scope:fail` | Action target is outside `AGENT_SCOPE_NAMESPACE` | Check `AGENT_SCOPE_NAMESPACE` matches the namespace being targetted |
| `MITIGATION_ALLOW_DISCOVERED_SCOPE must be set` | Running mitigate with empty `AGENT_SCOPE_NAMESPACE` and `MITIGATION_ALLOW_DISCOVERED_SCOPE=false` | Set `AGENT_SCOPE_NAMESPACE=litmus` explicitly |
| No Prometheus data in MCP tools | `prometheus-mcp-server` can't reach its backend | Verify `kubectl logs -n litmus -l app=prometheus-mcp-server`; the PROMETHEUS_URL must resolve |

---

## Repository Layout

```
flash-agent/
├── main.py                    ← entry point
├── flash_agent.py             ← FlashAgent class; _gated_execute() wires everything
├── config.py                  ← AgentConfig; all env vars in one place
├── build-flash-agent.sh       ← local dev build + kind image load + server env sync
├── ONBOARDING.md              ← this file
│
├── policy/
│   ├── classifier.py          ← tool tier: soft / hard / violent
│   ├── gate.py                ← ExecutionGate: scope + class enforcement
│   ├── chaos_guard.py         ← blocks during active chaos
│   ├── precondition.py        ← PDB, replica count, evidence checks
│   └── audit.py               ← JSONL audit log
│
├── llm/
│   ├── review.py              ← HardActionReviewer: 2-pass adversarial review
│   ├── playbook.py            ← learns from past episodes
│   └── hindsight.py           ← FLASH hindsight builder
│
├── memory/
│   ├── store.py               ← JSONL episode persistence
│   └── reconciler.py          ← compares past actions vs current state
│
└── mcp/client.py              ← MCPClient; connects to MCP servers
```

---

## Related docs (in ace-monorepo/docs/)

| File | Content |
|------|---------|
| `ace-onboarding-fresh.md` | Full ACE stack setup including Langfuse, certifier |
| `flash-agent-mitigation-what-changed.md` | Code changes introduced during mitigation feature development |
| `flash-agent-mitigation-onboarding.md` | Integration overview: where flash-agent fits in ace-monorepo |
| `flash-agent-mitigation-e2e-fresh-machine.md` | WSL isolated test guide |
